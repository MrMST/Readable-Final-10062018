exports.port = process.env.PORT || 3001
exports.origin = process.env.ORIGIN || `http://localhost:${exports.port}`
